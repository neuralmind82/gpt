# annual_repot
A langchain AI powered version of the Cisco 2022 Annual Report
