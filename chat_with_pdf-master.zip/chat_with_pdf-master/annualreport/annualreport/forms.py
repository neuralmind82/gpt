from django import forms
from .models import user_input

class UserInputForm(forms.ModelForm):
    class Meta:
        model = user_input
        fields = ["user_input"]
