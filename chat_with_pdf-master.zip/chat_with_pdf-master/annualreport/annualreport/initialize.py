import os
import openai
from langchain.document_loaders import PyMuPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.vectorstores import Chroma 
from langchain.chains import ConversationalRetrievalChain
from langchain.memory import ConversationBufferMemory
from langchain.chains import RetrievalQA
from langchain.chat_models import ChatOpenAI
from langchain.llms import OpenAI
from annualreport.models import Credentials

def initialize_components():
    # Fetch credentials from the database
    db_openai_token = Credentials.objects.all().values('openai_token')

    openai.api_key = db_openai_token[0]['openai_token']

    os.environ["OPENAI_API_KEY"] = openai.api_key

    loader = PyMuPDFLoader("cisco-annual-report-2022.pdf")
    pages = loader.load_and_split()

    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=250,
        chunk_overlap=20,
        length_function=len,
    )

    docs = text_splitter.split_documents(pages)

    embeddings = OpenAIEmbeddings()

    vectordb = Chroma.from_documents(pages, embedding=embeddings, 
                                 persist_directory=".")
    vectordb.persist()
    memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)
    pdf_qa = ConversationalRetrievalChain.from_llm(OpenAI(temperature=0.5) , vectordb.as_retriever(), memory=memory)

    return pdf_qa


def answer_question(qa, question):
    result = qa.run(question)  
    return(result)