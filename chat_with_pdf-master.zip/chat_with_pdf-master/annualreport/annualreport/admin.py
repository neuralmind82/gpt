from django.contrib import admin

from . import models

admin.site.register(models.Credentials)
admin.site.register(models.user_input)
admin.site.register(models.langchain_output)
