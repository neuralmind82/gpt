from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponse
from .forms import UserInputForm
from .models import user_input, langchain_output
from .initialize import initialize_components, answer_question

# Initialize components when the application starts
qa = initialize_components()

def chat(request):
    if request.method == 'POST':
        form = UserInputForm(request.POST)
        if form.is_valid():
            question = form.cleaned_data['user_input']
            form.save()
            answer = answer_question(qa, question)
            if answer is None:
                answer = "I'm sorry, I don't know how to answer that."
            # Save the answer to the database as well
            langchain_output_obj = langchain_output(user_input=question, langchain_output=answer)
            langchain_output_obj.save()
        else:
            print('Form is not valid:', form.errors)
    else:
        form = UserInputForm()

    # Get all past interactions from the database
    conversations = langchain_output.objects.order_by('id')

    return render(request, 'Home/home.html', {'form': form, 'conversations': conversations})

@csrf_exempt
def clear_data(request):
    if request.method == 'POST':
        user_input.objects.all().delete()
        langchain_output.objects.all().delete()
        form = UserInputForm()
        conversations = langchain_output.objects.order_by('id')
        return render(request, 'Home/home.html', {'form': form, 'conversations': conversations})