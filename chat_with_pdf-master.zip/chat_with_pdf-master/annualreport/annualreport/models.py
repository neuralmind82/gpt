from django.db import models

class Credentials(models.Model):
    openai_token = models.TextField()
    def __str__(self):
        template = '{0.openai_token}'
        return template.format(self)

class user_input(models.Model):
    user_input = models.TextField()

    def __str__(self):
        template = '{0.user_input}'
        return template.format(self)

class langchain_output(models.Model):
    user_input = models.TextField()
    langchain_output = models.TextField()

    def __str__(self):
        template = '{0.user_input} {0.langchain_output}'
        return template.format(self)